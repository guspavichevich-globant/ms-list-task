package com.prisma.mstasklist

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MsTaskListApplicationTests {

    @Test
    fun contextLoads() {
    }

}
